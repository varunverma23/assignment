/**
 * 
 */
package com.au.company;

/**
 * @author varun.f.verma
 *
 */

public class Divide implements Operation{

	@Override
	public double doOperation(double leftOperand, double rightOperand) {
		// TODO Auto-generated method stub
		return leftOperand / rightOperand;
	}
}
