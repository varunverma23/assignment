/**
 * 
 */
package com.au.company;

/**
 * @author varun.f.verma
 *
 */
public interface Operation {
    double doOperation(double leftOperand, double rightOperand);
}
